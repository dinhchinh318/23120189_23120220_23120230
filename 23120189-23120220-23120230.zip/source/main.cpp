#include "app.h"

int main() 
{
    runApp();

    exitProgram();

    return 0;
}
