#ifndef _APP_H_
#define _APP_H_

#include "QuanLyDienThoai.h"
#include "utils.h"

void runApp();

#endif