#include "utils.h"

void exitProgram()
{
    cout << "\n\nChuong trinh dang thoat. Vui long nhan phim Enter de thoat khoi chuong trinh\n";
    cin.get();
}